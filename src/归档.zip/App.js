import logo from './logo.svg';
import './App.css';
import IndexRouter from './router/indexRouter';
function App() {
  return (
    <div>
      <IndexRouter></IndexRouter>
    </div>
  );
}

export default App;
